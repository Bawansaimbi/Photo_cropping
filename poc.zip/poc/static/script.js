/**
 * Photo Cropping Utility - Frontend JavaScript
 * Handles UI interactions and manual crop tool
 */

class PhotoCropper {
  constructor() {
    this.currentFile = null;
    this.canvas = document.getElementById("cropCanvas");
    this.ctx = this.canvas.getContext("2d");
    this.cropBox = document.getElementById("cropBox");
    this.originalImage = null;
    this.isDragging = false;
    this.dragHandle = null;
    this.dragStart = { x: 0, y: 0 };

    this.initEventListeners();
  }

  initEventListeners() {
    // Upload area
    const uploadArea = document.getElementById("uploadArea");
    const fileInput = document.getElementById("fileInput");

    uploadArea.addEventListener("click", () => fileInput.click());
    uploadArea.addEventListener("dragover", (e) => this.handleDragOver(e));
    uploadArea.addEventListener("dragleave", (e) => this.handleDragLeave(e));
    uploadArea.addEventListener("drop", (e) => this.handleDrop(e));

    fileInput.addEventListener("change", (e) => this.handleFileSelect(e));

    // Crop handles
    document.querySelectorAll(".crop-handle").forEach((handle) => {
      handle.addEventListener("mousedown", (e) => this.startDrag(e));
    });

    // Crop buttons
    document
      .getElementById("resetCropBtn")
      ?.addEventListener("click", () => this.resetCropBox());
    document
      .getElementById("applyCropBtn")
      ?.addEventListener("click", () => this.applyCrop());

    // Reset buttons
    document
      .getElementById("resetBtn")
      ?.addEventListener("click", () => this.resetAll());
    document
      .getElementById("errorRetryBtn")
      ?.addEventListener("click", () => this.resetAll());

    // Validation section buttons
    document
      .getElementById("proceedManualBtn")
      ?.addEventListener("click", () => this.proceedToManualCrop());
    document
      .getElementById("retryUploadBtn")
      ?.addEventListener("click", () => this.resetAll());

    // Download button
    document.getElementById("downloadBtn")?.addEventListener("click", (e) => {
      // Download is handled by the href attribute
    });

    // Global mouse events for dragging
    document.addEventListener("mousemove", (e) => this.handleDragMove(e));
    document.addEventListener("mouseup", () => this.endDrag());
  }

  /* =====================
       Upload Handlers
       ===================== */

  handleDragOver(e) {
    e.preventDefault();
    e.stopPropagation();
    document.getElementById("uploadArea").classList.add("dragover");
  }

  handleDragLeave(e) {
    e.preventDefault();
    e.stopPropagation();
    document.getElementById("uploadArea").classList.remove("dragover");
  }

  handleDrop(e) {
    e.preventDefault();
    e.stopPropagation();
    document.getElementById("uploadArea").classList.remove("dragover");

    const files = e.dataTransfer.files;
    if (files.length > 0) {
      this.processFile(files[0]);
    }
  }

  handleFileSelect(e) {
    const file = e.target.files[0];
    if (file) {
      this.processFile(file);
    }
  }

  processFile(file) {
    if (!file.type.startsWith("image/")) {
      this.showError("Please select an image file");
      return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
      this.uploadFile(file);
    };
    reader.readAsArrayBuffer(file);
  }

  uploadFile(file) {
    const formData = new FormData();
    formData.append("file", file);

    // Show progress
    this.showProgress();

    fetch("/api/upload", {
      method: "POST",
      body: formData,
    })
      .then((response) => response.json())
      .then((data) => {
        this.hideProgress();

        if (data.success) {
          this.currentFile = data.original_file;
          this.showAutoProcessResult(data);
        } else if (
          data.validation_errors &&
          data.validation_errors.length > 0
        ) {
          // Show validation errors
          this.showValidationErrors(data);
        } else {
          if (data.requires_manual) {
            this.showManualCropInterface(data.original_file);
          } else {
            this.showError(data.error || "Upload failed");
          }
        }
      })
      .catch((error) => {
        this.hideProgress();
        this.showError(error.message);
      });
  }

  showProgress() {
    document.getElementById("uploadProgress").style.display = "block";
  }

  hideProgress() {
    document.getElementById("uploadProgress").style.display = "none";
  }

  /* =====================
       Auto Process Result
       ===================== */

  showAutoProcessResult(data) {
    const resultDiv = document.getElementById("autoProcessResult");
    resultDiv.innerHTML = `
            <p class="result-message success">✓ Photo processed successfully!</p>
            <p>Your photo has been automatically cropped to 2x2 inches with a white background.</p>
        `;
    resultDiv.classList.add("success");

    document.getElementById("uploadSection").style.display = "none";
    document.getElementById("processingSection").style.display = "block";

    // Load and display preview
    this.loadResultPreview(data.output_file);

    // Store download info
    document.getElementById("downloadBtn").href = data.download_url;

    setTimeout(() => {
      this.showResultSection(data.output_file);
    }, 1500);
  }

  showValidationErrors(data) {
    document.getElementById("uploadSection").style.display = "none";
    document.getElementById("processingSection").style.display = "none";
    document.getElementById("validationSection").style.display = "block";

    this.currentFile = data.original_file;

    // Display errors
    const errorsList = document.getElementById("validationErrors");
    const errorHTML = `
            <ul>
                ${data.validation_errors.map((err) => `<li>${err}</li>`).join("")}
            </ul>
        `;
    errorsList.innerHTML = errorHTML;

    // Display warnings if any
    if (data.validation_warnings && data.validation_warnings.length > 0) {
      errorsList.innerHTML += `
                <div style="margin-top: 20px; padding-top: 20px; border-top: 1px solid rgba(0,0,0,0.1);">
                    <strong style="color: var(--warning-color);">⚠️ Warnings:</strong>
                    <ul style="margin-top: 10px;">
                        ${data.validation_warnings.map((warn) => `<li style="color: var(--warning-color);">${warn}</li>`).join("")}
                    </ul>
                </div>
            `;
    }

    // Display validation details
    if (data.validation_details) {
      this.displayValidationDetails(data.validation_details);
    }
  }

  displayValidationDetails(details) {
    const detailsGrid = document.getElementById("validationDetails");
    let html = "";

    const checks = [
      { key: "resolution", label: "Resolution", format: (v) => v },
      {
        key: "is_square",
        label: "Square Format",
        format: (v) => (v ? "✓ Yes" : "✗ No"),
      },
      { key: "file_size_kb", label: "File Size", format: (v) => `${v}KB` },
      { key: "face_count", label: "Faces Detected", format: (v) => `${v}` },
      {
        key: "face_ratio",
        label: "Face Size Ratio",
        format: (v) => `${(v * 100).toFixed(0)}%`,
      },
      {
        key: "background_brightness",
        label: "Background",
        format: (v) => `${v}/255`,
      },
    ];

    checks.forEach((check) => {
      if (check.key in details) {
        const value = details[check.key];
        const isValid =
          (check.key === "is_square" && details.is_square) ||
          (check.key === "resolution_valid" && details.resolution_valid) ||
          (check.key === "file_size_valid" && details.file_size_valid) ||
          (check.key === "face_valid" && details.face_valid) ||
          (check.key === "face_size_valid" && details.face_size_valid) ||
          (check.key === "centered" && details.centered) ||
          (check.key === "background_white" && details.background_white) ||
          false;

        const statusClass = isValid
          ? "valid"
          : value === undefined
            ? ""
            : "invalid";
        const statusText =
          check.key === "is_square"
            ? value
              ? "Valid"
              : "Invalid"
            : check.key === "resolution_valid"
              ? value
                ? "Valid"
                : "Invalid"
              : check.key === "file_size_valid"
                ? value
                  ? "Valid"
                  : "Invalid"
                : check.key === "face_valid"
                  ? value
                    ? "Valid"
                    : "Invalid"
                  : check.key === "face_size_valid"
                    ? value
                      ? "Valid"
                      : "Invalid"
                    : check.key === "centered"
                      ? value
                        ? "Valid"
                        : "Invalid"
                      : check.key === "background_white"
                        ? value
                          ? "Valid"
                          : "Invalid"
                        : "";

        html += `
                    <div class="detail-item ${statusClass}">
                        <div class="detail-label">${check.label}</div>
                        <div class="detail-value">${check.format(value)}</div>
                        ${statusText ? `<div class="detail-status ${statusClass}">${statusText}</div>` : ""}
                    </div>
                `;
      }
    });

    detailsGrid.innerHTML = html;
  }

  proceedToManualCrop() {
    document.getElementById("validationSection").style.display = "none";
    this.showManualCropInterface(this.currentFile);
  }

  loadResultPreview(filename) {
    fetch(`/api/preview/${filename}`)
      .then((response) => response.json())
      .then((data) => {
        if (data.success) {
          document.getElementById("resultPreview").src = data.image;
        }
      })
      .catch((error) => console.error("Error loading preview:", error));
  }

  showResultSection(outputFile) {
    document.getElementById("processingSection").style.display = "none";
    document.getElementById("resultSection").style.display = "block";
  }

  /* =====================
       Manual Crop Interface
       ===================== */

  showManualCropInterface(originalFile) {
    this.currentFile = originalFile;

    // Load image
    fetch(`/api/get-upload/${originalFile}`)
      .then((response) => response.json())
      .then((data) => {
        if (data.success) {
          this.loadImageForCrop(data.image);
          document.getElementById("uploadSection").style.display = "none";
          document.getElementById("processingSection").style.display = "none";
          document.getElementById("manualCropSection").style.display = "block";
          document.getElementById("resultSection").style.display = "none";
        } else {
          this.showError("Could not load image for manual cropping");
        }
      })
      .catch((error) => this.showError(error.message));
  }

  loadImageForCrop(imageSrc) {
    const img = new Image();
    img.onload = () => {
      this.originalImage = img;
      this.drawCanvasWithImage(img);
      this.initializeCropBox();
    };
    img.src = imageSrc;
  }

  drawCanvasWithImage(img) {
    // Set canvas size
    const container = this.canvas.parentElement;
    const maxWidth = container.offsetWidth;
    const aspectRatio = img.width / img.height;

    this.canvas.width = maxWidth;
    this.canvas.height = maxWidth / aspectRatio;

    // Draw image
    this.ctx.drawImage(img, 0, 0, this.canvas.width, this.canvas.height);
  }

  initializeCropBox() {
    // Initialize crop box (30% margin)
    const margin = this.canvas.width * 0.15;
    const size = this.canvas.width - margin * 2;

    this.cropBox.style.left = margin + "px";
    this.cropBox.style.top = margin + "px";
    this.cropBox.style.width = size + "px";
    this.cropBox.style.height = size + "px";

    this.redrawCanvas();
  }

  resetCropBox() {
    if (this.originalImage) {
      this.drawCanvasWithImage(this.originalImage);
      this.initializeCropBox();
    }
  }

  redrawCanvas() {
    if (!this.originalImage) return;

    // Clear canvas
    this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);

    // Draw image
    this.ctx.drawImage(
      this.originalImage,
      0,
      0,
      this.canvas.width,
      this.canvas.height,
    );
  }

  /* =====================
       Crop Dragging
       ===================== */

  startDrag(e) {
    e.preventDefault();
    this.isDragging = true;
    this.dragHandle = e.target;
    this.dragStart = { x: e.clientX, y: e.clientY };

    const rect = this.cropBox.getBoundingClientRect();
    this.cropBoxStart = {
      left: parseInt(this.cropBox.style.left),
      top: parseInt(this.cropBox.style.top),
      width: parseInt(this.cropBox.style.width),
      height: parseInt(this.cropBox.style.height),
    };
  }

  handleDragMove(e) {
    if (!this.isDragging) return;

    const dx = e.clientX - this.dragStart.x;
    const dy = e.clientY - this.dragStart.y;

    const handleClass = this.dragHandle.className;

    if (handleClass.includes("top-left")) {
      this.resizeCropBox("top-left", dx, dy);
    } else if (handleClass.includes("top-right")) {
      this.resizeCropBox("top-right", dx, dy);
    } else if (handleClass.includes("bottom-left")) {
      this.resizeCropBox("bottom-left", dx, dy);
    } else if (handleClass.includes("bottom-right")) {
      this.resizeCropBox("bottom-right", dx, dy);
    } else if (handleClass.includes("top-center")) {
      this.resizeCropBox("top", dx, dy);
    } else if (handleClass.includes("bottom-center")) {
      this.resizeCropBox("bottom", dx, dy);
    } else if (handleClass.includes("left-center")) {
      this.resizeCropBox("left", dx, dy);
    } else if (handleClass.includes("right-center")) {
      this.resizeCropBox("right", dx, dy);
    }
  }

  resizeCropBox(direction, dx, dy) {
    const minSize = 50;
    let { left, top, width, height } = this.cropBoxStart;

    switch (direction) {
      case "top-left":
        left += dx;
        top += dy;
        width -= dx;
        height -= dy;
        break;
      case "top-right":
        top += dy;
        width += dx;
        height -= dy;
        break;
      case "bottom-left":
        left += dx;
        width -= dx;
        height += dy;
        break;
      case "bottom-right":
        width += dx;
        height += dy;
        break;
      case "top":
        top += dy;
        height -= dy;
        break;
      case "bottom":
        height += dy;
        break;
      case "left":
        left += dx;
        width -= dx;
        break;
      case "right":
        width += dx;
        break;
    }

    // Constraints
    left = Math.max(0, left);
    top = Math.max(0, top);
    width = Math.max(minSize, width);
    height = Math.max(minSize, height);
    width = Math.min(width, this.canvas.width - left);
    height = Math.min(height, this.canvas.height - top);

    // Apply
    this.cropBox.style.left = left + "px";
    this.cropBox.style.top = top + "px";
    this.cropBox.style.width = width + "px";
    this.cropBox.style.height = height + "px";
  }

  endDrag() {
    this.isDragging = false;
    this.dragHandle = null;
  }

  /* =====================
       Apply Crop
       ===================== */

  applyCrop() {
    const rect = this.cropBox.getBoundingClientRect();
    const canvasRect = this.canvas.getBoundingClientRect();

    // Calculate crop coordinates relative to original image
    const scaleX = this.originalImage.width / this.canvas.width;
    const scaleY = this.originalImage.height / this.canvas.height;

    const cropBox = {
      left: Math.round((rect.left - canvasRect.left) * scaleX),
      top: Math.round((rect.top - canvasRect.top) * scaleY),
      right: Math.round((rect.right - canvasRect.left) * scaleX),
      bottom: Math.round((rect.bottom - canvasRect.top) * scaleY),
    };

    // Send to backend
    document.getElementById("cropProgress").style.display = "block";

    fetch("/api/manual-crop", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        original_file: this.currentFile,
        crop_box: cropBox,
      }),
    })
      .then((response) => response.json())
      .then((data) => {
        document.getElementById("cropProgress").style.display = "none";

        if (data.success) {
          this.currentFile = data.output_file;
          document.getElementById("downloadBtn").href = data.download_url;
          this.showManualResultSection(data.output_file);
        } else {
          this.showError(data.error || "Cropping failed");
        }
      })
      .catch((error) => {
        document.getElementById("cropProgress").style.display = "none";
        this.showError(error.message);
      });
  }

  showManualResultSection(outputFile) {
    document.getElementById("manualCropSection").style.display = "none";
    document.getElementById("resultSection").style.display = "block";
    this.loadResultPreview(outputFile);
  }

  /* =====================
       Error & Reset
       ===================== */

  showError(message) {
    document.getElementById("uploadSection").style.display = "none";
    document.getElementById("processingSection").style.display = "none";
    document.getElementById("manualCropSection").style.display = "none";
    document.getElementById("resultSection").style.display = "none";
    document.getElementById("errorSection").style.display = "block";
    document.getElementById("errorMessage").textContent = message;
  }

  resetAll() {
    // Reset all sections
    document.getElementById("uploadSection").style.display = "block";
    document.getElementById("processingSection").style.display = "none";
    document.getElementById("validationSection").style.display = "none";
    document.getElementById("manualCropSection").style.display = "none";
    document.getElementById("resultSection").style.display = "none";
    document.getElementById("errorSection").style.display = "none";

    // Reset form
    document.getElementById("fileInput").value = "";
    document.getElementById("uploadArea").classList.remove("dragover");

    // Reset state
    this.currentFile = null;
    this.originalImage = null;
  }
}

// Initialize on page load
document.addEventListener("DOMContentLoaded", () => {
  new PhotoCropper();
});
