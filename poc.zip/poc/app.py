"""
Flask Application for Photo Cropping Utility
Provides automatic and manual photo cropping with web interface.
"""

from flask import Flask, render_template, request, send_file, jsonify
from flask_cors import CORS
from werkzeug.utils import secure_filename
import os
import uuid
from datetime import datetime
from photo_cropper import PhotoCropper
import base64

app = Flask(__name__)
CORS(app)

# Configuration
UPLOAD_FOLDER = 'uploads'
OUTPUT_FOLDER = 'output'
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif', 'bmp', 'webp'}
MAX_FILE_SIZE = 20 * 1024 * 1024  # 20MB

# Create folders if they don't exist
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(OUTPUT_FOLDER, exist_ok=True)

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['OUTPUT_FOLDER'] = OUTPUT_FOLDER
app.config['MAX_CONTENT_LENGTH'] = MAX_FILE_SIZE

# Initialize PhotoCropper
cropper = PhotoCropper(dpi=96)


def allowed_file(filename):
    """Check if file extension is allowed."""
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


def generate_filename(original_filename):
    """Generate unique filename."""
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    unique_id = str(uuid.uuid4())[:8]
    ext = original_filename.rsplit('.', 1)[1].lower()
    return f"{timestamp}_{unique_id}.{ext}"


@app.route('/')
def index():
    """Serve the main page."""
    return render_template('index.html')


@app.route('/api/upload', methods=['POST'])
def upload_file():
    """Handle file upload and automatic cropping."""
    try:
        if 'file' not in request.files:
            return jsonify({'success': False, 'error': 'No file provided'}), 400
        
        file = request.files['file']
        
        if file.filename == '':
            return jsonify({'success': False, 'error': 'No file selected'}), 400
        
        if not allowed_file(file.filename):
            return jsonify({'success': False, 'error': 'File type not allowed'}), 400
        
        # Save uploaded file
        original_filename = generate_filename(file.filename)
        upload_path = os.path.join(app.config['UPLOAD_FOLDER'], original_filename)
        file.save(upload_path)
        
        # Validate photo before processing
        validation_result = cropper.validate_photo(upload_path)
        
        if not validation_result['valid']:
            return jsonify({
                'success': False,
                'requires_manual': True,
                'original_file': original_filename,
                'validation_errors': validation_result['errors'],
                'validation_warnings': validation_result.get('warnings', []),
                'validation_details': validation_result.get('details', {}),
                'error': 'Photo does not meet requirements. Please adjust and try again, or proceed to manual crop.'
            }), 400
        
        # Try automatic cropping
        output_filename = f"cropped_{original_filename}"
        output_path = os.path.join(app.config['OUTPUT_FOLDER'], output_filename)
        
        success = cropper.crop_photo_auto(upload_path, output_path)
        
        if success:
            return jsonify({
                'success': True,
                'message': 'Photo cropped automatically',
                'original_file': original_filename,
                'output_file': output_filename,
                'download_url': f'/api/download/{output_filename}',
                'preview_url': f'/api/preview/{output_filename}',
                'validation_details': validation_result.get('details', {})
            })
        else:
            return jsonify({
                'success': False,
                'error': 'Automatic cropping failed',
                'original_file': original_filename,
                'requires_manual': True
            }), 400
            
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/manual-crop', methods=['POST'])
def manual_crop():
    """Handle manual cropping with user-provided crop coordinates."""
    try:
        data = request.get_json()
        
        if not data.get('original_file'):
            return jsonify({'success': False, 'error': 'Original file not provided'}), 400
        
        if not data.get('crop_box'):
            return jsonify({'success': False, 'error': 'Crop coordinates not provided'}), 400
        
        # Get crop box coordinates
        crop_box = data['crop_box']
        crop_coords = (
            int(crop_box['left']),
            int(crop_box['top']),
            int(crop_box['right']),
            int(crop_box['bottom'])
        )
        
        # Load original file
        upload_path = os.path.join(app.config['UPLOAD_FOLDER'], data['original_file'])
        
        if not os.path.exists(upload_path):
            return jsonify({'success': False, 'error': 'Original file not found'}), 404
        
        # Perform manual crop
        output_filename = f"cropped_{data['original_file']}"
        output_path = os.path.join(app.config['OUTPUT_FOLDER'], output_filename)
        
        success = cropper.crop_photo_manual(upload_path, output_path, crop_coords)
        
        if success:
            return jsonify({
                'success': True,
                'message': 'Photo cropped manually',
                'output_file': output_filename,
                'download_url': f'/api/download/{output_filename}',
                'preview_url': f'/api/preview/{output_filename}'
            })
        else:
            return jsonify({
                'success': False,
                'error': 'Manual cropping failed'
            }), 400
            
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/preview/<filename>')
def preview(filename):
    """Get preview image as base64 for display."""
    try:
        filename = secure_filename(filename)
        filepath = os.path.join(app.config['OUTPUT_FOLDER'], filename)
        
        if not os.path.exists(filepath):
            return jsonify({'success': False, 'error': 'File not found'}), 404
        
        with open(filepath, 'rb') as f:
            image_bytes = f.read()
            b64_image = base64.b64encode(image_bytes).decode()
        
        return jsonify({
            'success': True,
            'image': f'data:image/jpeg;base64,{b64_image}'
        })
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/download/<filename>')
def download(filename):
    """Download cropped image."""
    try:
        filename = secure_filename(filename)
        filepath = os.path.join(app.config['OUTPUT_FOLDER'], filename)
        
        if not os.path.exists(filepath):
            return jsonify({'success': False, 'error': 'File not found'}), 404
        
        return send_file(filepath, as_attachment=True)
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/get-upload/<filename>')
def get_upload_preview(filename):
    """Get preview of original uploaded file for manual cropping."""
    try:
        filename = secure_filename(filename)
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        
        if not os.path.exists(filepath):
            return jsonify({'success': False, 'error': 'File not found'}), 404
        
        with open(filepath, 'rb') as f:
            image_bytes = f.read()
            b64_image = base64.b64encode(image_bytes).decode()
        
        return jsonify({
            'success': True,
            'image': f'data:image/jpeg;base64,{b64_image}'
        })
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/health')
def health():
    """Health check endpoint."""
    return jsonify({'status': 'ok'})


@app.errorhandler(413)
def too_large(e):
    """Handle file too large error."""
    return jsonify({'success': False, 'error': 'File too large. Maximum size is 20MB'}), 413


if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
