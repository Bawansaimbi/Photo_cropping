# Photo Cropping Utility

Automatic photo cropping system for applicant photos. Crops images to **2x2 inches** with a **white background**, with manual override capabilities for exceptions.

## Features

- **Automatic Cropping**: Instantly crops photos to 2×2 inches with white background
- **Manual Override**: Interactive crop tool for fine-tuning when automatic processing isn't perfect
- **Web Interface**: User-friendly drag-and-drop upload with live preview
- **Exception Handling**: Graceful fallback to manual cropping if automatic processing fails
- **Download Ready**: Processed photos are ready for download and submission

## System Architecture

```
Photo Cropping Utility
├── photo_cropper.py      # Core image processing engine
├── app.py                # Flask web server & API
├── requirements.txt      # Python dependencies
├── templates/
│   └── index.html        # Web interface
└── static/
    ├── style.css         # Styling
    └── script.js         # Interactive features
```

## Installation

### Prerequisites

- Python 3.8+
- pip

### Setup

1. **Clone or navigate to the project directory**

   ```bash
   cd path/to/stock-tracker/poc
   ```

2. **Create a virtual environment (recommended)**

   ```bash
   python -m venv venv
   ```

   On Windows:

   ```bash
   venv\Scripts\activate
   ```

   On macOS/Linux:

   ```bash
   source venv/bin/activate
   ```

3. **Install dependencies**

   ```bash
   pip install -r requirements.txt
   ```

4. **Create necessary directories**
   ```bash
   mkdir uploads output
   ```

## Usage

### Starting the Server

```bash
python app.py
```

The application will be available at `http://localhost:5000`

### Using the Web Interface

1. **Upload Photo**
   - Click the upload area or drag & drop your photo
   - Supported formats: JPG, PNG, GIF, BMP, WebP
   - Maximum file size: 20MB

2. **Automatic Processing**
   - The system attempts to auto-crop your photo
   - If successful, you'll see the result immediately
   - Download your 2×2 inch photo

3. **Manual Adjustment (if needed)**
   - If automatic processing has issues, you'll be guided to manual mode
   - Use the interactive crop tool to adjust the crop area
   - Resize by dragging the corner and edge handles
   - Reset if needed and re-apply

4. **Download Result**
   - Once satisfied, download your cropped photo
   - Photo is 2×2 inches at 96 DPI
   - White background included
   - Ready for submission

## API Endpoints

### Upload & Auto-Crop

```
POST /api/upload
Content-Type: multipart/form-data
- file: image file
Returns: JSON with success status, output file path, and preview URL
```

### Manual Crop

```
POST /api/manual-crop
Content-Type: application/json
{
  "original_file": "filename.jpg",
  "crop_box": {
    "left": 100,
    "top": 100,
    "right": 300,
    "bottom": 300
  }
}
Returns: JSON with success status and output file path
```

### Download Cropped Image

```
GET /api/download/<filename>
Returns: Image file for download
```

### Get Preview

```
GET /api/preview/<filename>
Returns: JSON with base64-encoded image data
```

## Photo Specifications

- **Dimensions**: 2 inches × 2 inches
- **DPI**: 96 DPI (web standard)
- **Pixel Size**: 192 × 192 pixels
- **Background**: White (#FFFFFF)
- **Format**: JPEG
- **Quality**: 95%

## Troubleshooting

### "File too large" error

- Maximum file size is 20MB
- Compress your image and try again

### Automatic cropping fails

- The system will guide you to manual crop mode
- Use the interactive tool to select the crop area manually
- This typically happens with unusual image aspect ratios

### Downloaded image looks pixelated

- Ensure you're uploading a high-quality source image
- For best results, upload images at least 300×300 pixels

## Technical Details

### Image Processing Pipeline

1. **Input Validation**
   - Check file type and size
   - Load image with PIL

2. **Automatic Cropping**
   - Detect center content
   - Crop to square
   - Resize maintaining aspect ratio
   - Add white padding

3. **Quality Assurance**
   - Convert to RGB if needed
   - Add DPI metadata (96 DPI)
   - Save with quality 95

### Error Handling

- Invalid file types are rejected
- Oversized files are blocked
- Processing errors trigger manual mode
- All errors are logged with descriptions

## File Structure

```
uploads/      → Temporary storage for uploaded images
output/       → Final processed images (ready to download)
templates/    → HTML web interface
static/       → CSS styling and JavaScript functionality
```

## Configuration

Edit `.env` or modify settings in `app.py`:

```python
UPLOAD_FOLDER = 'uploads'      # Where uploads are stored
OUTPUT_FOLDER = 'output'       # Where processed images are saved
MAX_FILE_SIZE = 20 * 1024 * 1024  # 20MB
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif', 'bmp', 'webp'}
```

## Production Deployment

For production use:

1. **Set Flask to production mode**

   ```python
   app.run(debug=False)
   ```

2. **Use a production WSGI server** (e.g., Gunicorn)

   ```bash
   pip install gunicorn
   gunicorn -w 4 app:app
   ```

3. **Add security headers** and HTTPS
4. **Implement cleanup** for old uploaded files
5. **Set up logging** and monitoring
6. **Configure storage** for scalability (cloud storage, CDN)

## Security Considerations

- File upload validation (type and size)
- Secure filename handling
- CORS enabled for integration
- No sensitive data in file names
- Regular cleanup of uploaded files recommended

## Performance

- **Upload**: Typically < 2 seconds for standard images
- **Auto-crop**: < 1 second processing time
- **Manual adjustment**: Real-time in browser
- **Download**: Instant file delivery

## Browser Compatibility

- Chrome 90+
- Firefox 88+
- Safari 14+
- Edge 90+

## Maintenance

### Cleanup Old Files

Periodically remove old uploaded files:

```bash
# Remove uploads older than 7 days (Linux/macOS)
find uploads/ -type f -mtime +7 -delete
```

### Monitor Disk Usage

Keep track of `uploads/` and `output/` folder sizes, especially in production.

## Future Enhancements

- [ ] Batch processing multiple photos
- [ ] Advanced face detection for auto-centering
- [ ] Multiple output formats (PNG, TIFF)
- [ ] User accounts and photo history
- [ ] Email delivery of processed photos
- [ ] API key authentication for integration
- [ ] Progress indicators for slow connections

## License

This is a utility for applicant photo processing.

## Support

For issues or questions, please refer to the troubleshooting section or contact your system administrator.

---

**Version**: 1.0.0  
**Last Updated**: February 23, 2026
