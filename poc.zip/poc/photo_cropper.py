"""
Photo Cropping Utility
Automatically crops photos to 2x2 inches with white background using face detection.
Supports manual override for exceptions.
"""

from PIL import Image, ImageOps
from io import BytesIO
import os
from typing import Tuple, Optional, List
import cv2
import numpy as np


class PhotoCropper:
    """Handles automatic and manual photo cropping to 2x2 inches with white background."""
    
    # 2 inches at 96 DPI = 192 pixels (standard web DPI)
    # 2 inches at 300 DPI = 600 pixels (print quality)
    DEFAULT_DPI = 96
    CROP_SIZE_INCHES = 2
    TARGET_SIZE = int(CROP_SIZE_INCHES * DEFAULT_DPI)  # 192x192 pixels
    BACKGROUND_COLOR = (255, 255, 255)  # White
    
    def __init__(self, dpi: int = DEFAULT_DPI):
        """
        Initialize PhotoCropper with face detection cascade.
        
        Args:
            dpi: Dots per inch for conversion. Default is 96 (web standard).
        """
        self.dpi = dpi
        self.target_size = int(self.CROP_SIZE_INCHES * dpi)
        
        # Load face detection cascades
        self.face_cascade = cv2.CascadeClassifier(
            cv2.data.haarcascades + 'haarcascade_frontalface_default.xml'
        )
        self.eye_cascade = cv2.CascadeClassifier(
            cv2.data.haarcascades + 'haarcascade_eye.xml'
        )
    
    def _to_serializable(self, obj):
        """Convert numpy types to Python native types for JSON serialization."""
        if isinstance(obj, dict):
            return {k: self._to_serializable(v) for k, v in obj.items()}
        elif isinstance(obj, (list, tuple)):
            return [self._to_serializable(item) for item in obj]
        elif isinstance(obj, np.bool_):
            return bool(obj)
        elif isinstance(obj, (np.integer, np.floating)):
            return obj.item()
        else:
            return obj
    
    def correct_resolution(self, img: Image.Image, target_width: int = 800) -> Image.Image:
        """
        Automatically correct image resolution to valid range (600-1200px).
        
        Args:
            img: PIL Image object
            target_width: Target width in pixels (600-1200)
            
        Returns:
            Resized image
        """
        width, height = img.size
        
        # If already in valid range, return as is
        if 600 <= width <= 1200 and 600 <= height <= 1200:
            return img
        
        # Calculate resize ratio maintaining aspect ratio
        max_dim = max(width, height)
        
        if max_dim < 600:
            # Image too small, scale up
            scale = 600 / max_dim
        elif max_dim > 1200:
            # Image too large, scale down
            scale = 1200 / max_dim
        else:
            scale = 1
        
        new_width = int(width * scale)
        new_height = int(height * scale)
        
        print(f"Correcting resolution from {width}×{height} to {new_width}×{new_height}")
        
        # Resize with high quality
        return img.resize((new_width, new_height), Image.Resampling.LANCZOS)
    
    def validate_photo(self, input_path: str) -> dict:
        """
        Validate photo against US Visa photo requirements.
        
        Returns:
            Dictionary with validation results and any errors found
        """
        results = {
            "valid": True,
            "errors": [],
            "warnings": [],
            "details": {}
        }
        
        try:
            # Load image with OpenCV
            img_cv = cv2.imread(input_path)
            if img_cv is None:
                results["valid"] = False
                results["errors"].append("Invalid or corrupted image file")
                return results
            
            height, width, _ = img_cv.shape
            
            # ---------- 1. Check Square ----------
            results["details"]["is_square"] = (width == height)
            if not results["details"]["is_square"]:
                results["errors"].append(f"Image must be square. Current: {width}×{height}px")
            
            # ---------- 2. Check Resolution ----------
            results["details"]["resolution"] = f"{width}×{height}"
            results["details"]["resolution_valid"] = (600 <= width <= 1200)
            if not results["details"]["resolution_valid"]:
                results["warnings"].append(f"Resolution {width}×{height}px is outside optimal range (600-1200px). Will be auto-corrected.")
            
            # ---------- 3. Check File Size ----------
            file_size_kb = os.path.getsize(input_path) / 1024
            results["details"]["file_size_kb"] = round(file_size_kb, 2)
            results["details"]["file_size_valid"] = (file_size_kb <= 240)
            if not results["details"]["file_size_valid"]:
                results["errors"].append(f"File size must be ≤240KB. Current: {file_size_kb:.1f}KB")
            
            # ---------- 4. Face Detection ----------
            gray = cv2.cvtColor(img_cv, cv2.COLOR_BGR2GRAY)
            faces = self.face_cascade.detectMultiScale(gray, 1.1, 5)
            
            results["details"]["face_count"] = len(faces)
            
            if len(faces) == 0:
                results["errors"].append("No face detected in image. Ensure your face is clearly visible.")
                results["details"]["face_valid"] = False
            elif len(faces) > 1:
                results["errors"].append(f"Multiple faces detected ({len(faces)}). Only one face should be in the image.")
                results["details"]["face_valid"] = False
            else:
                results["details"]["face_valid"] = True
                
                x, y, w, h = faces[0]
                
                # ---------- 5. Face Size Ratio ----------
                face_ratio = h / height
                results["details"]["face_ratio"] = round(face_ratio, 3)
                results["details"]["face_size_valid"] = (0.50 <= face_ratio <= 0.69)
                
                if not results["details"]["face_size_valid"]:
                    if face_ratio < 0.50:
                        results["errors"].append(f"Face is too small. Must occupy 50-69% of image height. Current: {face_ratio*100:.0f}%")
                    else:
                        results["errors"].append(f"Face is too large. Must occupy 50-69% of image height. Current: {face_ratio*100:.0f}%")
                
                # ---------- 6. Centering Check ----------
                center_x = x + w / 2
                center_y = y + h / 2
                
                image_center_x = width / 2
                image_center_y = height / 2
                
                offset_x = abs(center_x - image_center_x) / width
                offset_y = abs(center_y - image_center_y) / height
                
                results["details"]["offset_x"] = round(offset_x, 3)
                results["details"]["offset_y"] = round(offset_y, 3)
                results["details"]["centered"] = (offset_x < 0.05 and offset_y < 0.05)
                
                if not results["details"]["centered"]:
                    results["errors"].append(f"Face is not centered. Keep face centered in the frame.")
            
            # ---------- 7. Background Check ----------
            if len(faces) > 0:
                x, y, w, h = faces[0]
                # Sample corners for background color
                corner_samples = [
                    img_cv[10:60, 10:60],
                    img_cv[10:60, max(0, width-60):width-10],
                    img_cv[max(0, height-60):height-10, 10:60],
                    img_cv[max(0, height-60):height-10, max(0, width-60):width-10]
                ]
                
                avg_colors = [np.mean(sample) for sample in corner_samples if sample.size > 0]
                avg_background = np.mean(avg_colors) if avg_colors else 255
                
                results["details"]["background_brightness"] = round(avg_background, 1)
                results["details"]["background_white"] = (avg_background > 200)
                
                if not results["details"]["background_white"]:
                    results["warnings"].append("Background is not purely white. Ensure background is plain white.")
            
            # ---------- Final Verdict ----------
            results["valid"] = len(results["errors"]) == 0
            
            return self._to_serializable(results)
            
        except Exception as e:
            results["valid"] = False
            results["errors"].append(f"Validation error: {str(e)}")
            return self._to_serializable(results)
    
        """
        Detect faces in image using Haar Cascade classifier.
        
        Args:
            image_array: Image as numpy array (BGR format from OpenCV)
            
        Returns:
            List of face bounding boxes (x, y, w, h)
        """
        try:
            # Convert to grayscale for detection
            gray = cv2.cvtColor(image_array, cv2.COLOR_BGR2GRAY)
            
            # Detect faces
            faces = self.face_cascade.detectMultiScale(
                gray,
                scaleFactor=1.1,
                minNeighbors=5,
                minSize=(30, 30),
                maxSize=(500, 500)
            )
            
            return faces
        except Exception as e:
            print(f"Face detection error: {str(e)}")
            return []
    
    def get_crop_box_from_face(self, image_array: np.ndarray, faces: List[Tuple[int, int, int, int]]) -> Tuple[int, int, int, int]:
        """
        Calculate optimal crop box based on detected faces.
        Ensures face is centered with appropriate padding.
        
        Args:
            image_array: Image as numpy array
            faces: List of detected face bounding boxes
            
        Returns:
            Crop box coordinates (x, y, w, h) or None if no faces
        """
        if len(faces) == 0:
            return None
        
        height, width = image_array.shape[:2]
        
        # Get the largest face (usually the main subject)
        largest_face = max(faces, key=lambda f: f[2] * f[3])
        fx, fy, fw, fh = largest_face
        
        # Calculate face center
        face_center_x = fx + fw // 2
        face_center_y = fy + fh // 2
        
        # Calculate crop size (square)
        # Make crop box large enough to include face with padding
        min_crop_size = int(max(fw, fh) * 1.4)  # 40% padding around face
        crop_size = min(min_crop_size, min(width, height))
        
        # Ensure crop_size is reasonable
        crop_size = max(100, crop_size)
        crop_size = min(crop_size, min(width, height))
        
        # Calculate crop box with face centered
        left = max(0, face_center_x - crop_size // 2)
        top = max(0, face_center_y - crop_size // 2)
        
        # Adjust if crop box goes out of bounds
        if left + crop_size > width:
            left = width - crop_size
        if top + crop_size > height:
            top = height - crop_size
        
        left = max(0, left)
        top = max(0, top)
        
        return (left, top, crop_size, crop_size)
    
    def crop_photo_auto(self, input_path: str, output_path: str) -> bool:
        """
        Automatically crop and process photo to 2x2 inches with white background.
        Uses face detection for intelligent cropping.
        
        This method:
        1. Detects faces in the image
        2. Centers crop on detected face
        3. Crops to 2x2 inches
        4. Adds white background
        
        Args:
            input_path: Path to input image file
            output_path: Path to save processed image
            
        Returns:
            True if successful, False if failed
        """
        try:
            # Open image with PIL
            img = Image.open(input_path)
            
            # Convert to RGB if necessary
            if img.mode != 'RGB':
                img = img.convert('RGB')
            
            # Automatically correct resolution if needed
            img = self.correct_resolution(img)
            
            # Convert PIL image to OpenCV format for face detection
            img_cv = cv2.cvtColor(np.array(img), cv2.COLOR_RGB2BGR)
            
            # Detect faces
            faces = self.detect_faces(img_cv)
            
            # Get crop box based on faces or fallback to center
            if len(faces) > 0:
                crop_result = self.get_crop_box_from_face(img_cv, faces)
                if crop_result:
                    x, y, w, h = crop_result
                    # Convert to PIL crop format (left, top, right, bottom)
                    crop_box = (x, y, x + w, y + h)
                else:
                    # Fallback to center crop
                    crop_box = self._get_center_crop_box(img)
            else:
                # No faces detected, use center crop
                crop_box = self._get_center_crop_box(img)
            
            # Crop to square
            img_cropped = img.crop(crop_box)
            
            # Resize to target size maintaining aspect ratio
            img_cropped.thumbnail((self.target_size, self.target_size), Image.Resampling.LANCZOS)
            
            # Create white background
            final_img = Image.new('RGB', (self.target_size, self.target_size), self.BACKGROUND_COLOR)
            
            # Paste cropped image centered on white background
            offset = ((self.target_size - img_cropped.width) // 2,
                     (self.target_size - img_cropped.height) // 2)
            final_img.paste(img_cropped, offset)
            
            # Save with DPI metadata
            final_img.save(output_path, dpi=(self.dpi, self.dpi), quality=95)
            return True
            
        except Exception as e:
            print(f"Error in automatic cropping: {str(e)}")
            return False
    
    def _get_center_crop_box(self, img: Image.Image) -> Tuple[int, int, int, int]:
        """
        Get center crop box coordinates.
        
        Args:
            img: PIL Image object
            
        Returns:
            Crop box (left, top, right, bottom)
        """
        width, height = img.size
        crop_size = min(width, height)
        left = (width - crop_size) // 2
        top = (height - crop_size) // 2
        right = left + crop_size
        bottom = top + crop_size
        return (left, top, right, bottom)
    
    def crop_photo_manual(self, input_path: str, output_path: str,
                          crop_box: Tuple[int, int, int, int]) -> bool:
        """
        Manually crop photo with specified crop box.
        
        Args:
            input_path: Path to input image file
            output_path: Path to save processed image
            crop_box: Tuple of (left, top, right, bottom) coordinates
            
        Returns:
            True if successful, False if failed
        """
        try:
            img = Image.open(input_path)
            
            # Convert to RGB if necessary
            if img.mode != 'RGB':
                img = img.convert('RGB')
            
            # Automatically correct resolution if needed
            img = self.correct_resolution(img)
            
            # Crop using provided coordinates
            img_cropped = img.crop(crop_box)
            
            # Resize to target size maintaining aspect ratio
            img_cropped.thumbnail((self.target_size, self.target_size), Image.Resampling.LANCZOS)
            
            # Create white background
            final_img = Image.new('RGB', (self.target_size, self.target_size), self.BACKGROUND_COLOR)
            
            # Paste cropped image centered on white background
            offset = ((self.target_size - img_cropped.width) // 2,
                     (self.target_size - img_cropped.height) // 2)
            final_img.paste(img_cropped, offset)
            
            # Save with DPI metadata
            final_img.save(output_path, dpi=(self.dpi, self.dpi), quality=95)
            return True
            
        except Exception as e:
            print(f"Error in manual cropping: {str(e)}")
            return False
    
    def crop_photo_from_bytes(self, image_bytes: bytes, output_path: str) -> bool:
        """
        Crop photo from bytes (useful for web uploads).
        
        Args:
            image_bytes: Image data as bytes
            output_path: Path to save processed image
            
        Returns:
            True if successful, False if failed
        """
        try:
            img = Image.open(BytesIO(image_bytes))
            
            # Convert to RGB if necessary
            if img.mode != 'RGB':
                img = img.convert('RGB')
            
            # Automatically correct resolution if needed
            img = self.correct_resolution(img)
            
            # Calculate crop box (center crop)
            width, height = img.size
            crop_size = min(width, height)
            left = (width - crop_size) // 2
            top = (height - crop_size) // 2
            right = left + crop_size
            bottom = top + crop_size
            
            # Crop to square
            img_cropped = img.crop((left, top, right, bottom))
            
            # Resize to target size maintaining aspect ratio
            img_cropped.thumbnail((self.target_size, self.target_size), Image.Resampling.LANCZOS)
            
            # Create white background
            final_img = Image.new('RGB', (self.target_size, self.target_size), self.BACKGROUND_COLOR)
            
            # Paste cropped image centered on white background
            offset = ((self.target_size - img_cropped.width) // 2,
                     (self.target_size - img_cropped.height) // 2)
            final_img.paste(img_cropped, offset)
            
            # Save with DPI metadata
            final_img.save(output_path, dpi=(self.dpi, self.dpi), quality=95)
            return True
            
        except Exception as e:
            print(f"Error processing image bytes: {str(e)}")
            return False
    
    def get_preview_bytes(self, input_path: str, size: int = 300) -> Optional[bytes]:
        """
        Get preview image as bytes for display in web UI.
        
        Args:
            input_path: Path to input image file
            size: Preview size in pixels
            
        Returns:
            Image bytes or None if failed
        """
        try:
            img = Image.open(input_path)
            
            # Convert to RGB if necessary
            if img.mode != 'RGB':
                img = img.convert('RGB')
            
            # Create thumbnail for preview
            img.thumbnail((size, size), Image.Resampling.LANCZOS)
            
            # Convert to bytes
            buffer = BytesIO()
            img.save(buffer, format='JPEG', quality=85)
            return buffer.getvalue()
            
        except Exception as e:
            print(f"Error generating preview: {str(e)}")
            return None
