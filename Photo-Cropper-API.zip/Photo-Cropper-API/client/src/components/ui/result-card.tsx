import { motion } from "framer-motion";
import { Download, CheckCircle, RefreshCcw } from "lucide-react";
import { Button } from "@/components/ui/button";

interface ResultCardProps {
  imageUrl: string;
  onDownload: () => void;
  onReset: () => void;
}

export function ResultCard({ imageUrl, onDownload, onReset }: ResultCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-card rounded-2xl shadow-xl shadow-primary/5 border border-border overflow-hidden"
    >
      <div className="p-6 md:p-8 flex flex-col md:flex-row gap-8 items-center">
        <div className="relative shrink-0">
          <div className="w-48 h-48 md:w-64 md:h-64 rounded-xl overflow-hidden shadow-inner border border-border bg-muted relative group">
            <img 
              src={imageUrl} 
              alt="Processed Result" 
              className="w-full h-full object-contain"
            />
            {/* Grid overlay to show transparency/cropping alignment */}
            <div className="absolute inset-0 pointer-events-none bg-[url('data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyMCIgaGVpZ2h0PSIyMCIgZmlsbD0ibm9uZSI+PHBhdGggZD0iTTEgMjBWMH0iIHN0cm9rZT0icmdiYSgwLDAsMCwwLjA1KSIvPjxwYXRoIGQ9Ik0wIDE5aDIwIiBzdHJva2U9InJnYmEoMCwwLDAsMC4wNSkiLz48L3N2Zz4=')] opacity-50"></div>
          </div>
          <div className="absolute -bottom-3 -right-3 bg-green-500 text-white p-2 rounded-full shadow-lg">
            <CheckCircle className="w-6 h-6" />
          </div>
        </div>

        <div className="flex flex-col gap-4 text-center md:text-left flex-1">
          <div>
            <h3 className="text-2xl font-bold text-foreground">Perfectly Cropped!</h3>
            <p className="text-muted-foreground mt-2">
              Your photo has been processed to meet standard passport requirements. 
              The face is centered and scaled to ~60% height.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row gap-3 mt-2 justify-center md:justify-start">
            <Button 
              onClick={onDownload} 
              size="lg" 
              className="font-semibold shadow-lg shadow-primary/20 hover:shadow-primary/30 transition-all"
            >
              <Download className="w-4 h-4 mr-2" />
              Download Photo
            </Button>
            <Button 
              onClick={onReset} 
              variant="outline" 
              size="lg"
            >
              <RefreshCcw className="w-4 h-4 mr-2" />
              Process Another
            </Button>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
