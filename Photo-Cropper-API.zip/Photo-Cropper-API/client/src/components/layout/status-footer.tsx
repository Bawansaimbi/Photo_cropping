import { cn } from "@/lib/utils";

interface StatusFooterProps {
  isOnline: boolean;
  message?: string;
}

export function StatusFooter({ isOnline, message }: StatusFooterProps) {
  return (
    <footer className="w-full py-6 border-t border-border mt-auto">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between text-sm text-muted-foreground">
        <p>© 2024 Passport Photo Utility</p>
        <div className="flex items-center gap-2">
          <span className="relative flex h-2.5 w-2.5">
            <span className={cn(
              "animate-ping absolute inline-flex h-full w-full rounded-full opacity-75",
              isOnline ? "bg-green-400" : "bg-red-400"
            )}></span>
            <span className={cn(
              "relative inline-flex rounded-full h-2.5 w-2.5",
              isOnline ? "bg-green-500" : "bg-red-500"
            )}></span>
          </span>
          <span>{isOnline ? "System Online" : "System Offline"}</span>
        </div>
      </div>
    </footer>
  );
}
