import { useState } from "react";
import { usePhotoProcessor } from "@/hooks/use-photo-processor";
import { Dropzone } from "@/components/ui/dropzone";
import { Button } from "@/components/ui/button";
import { ResultCard } from "@/components/ui/result-card";
import { StatusFooter } from "@/components/layout/status-footer";
import { Loader2, Crop, ShieldCheck, Zap, AlertCircle } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

export default function Home() {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const { processPhoto, isProcessing, processedImage, error, reset, isApiOnline } = usePhotoProcessor();

  const handleProcess = () => {
    if (selectedFile) {
      processPhoto(selectedFile);
    }
  };

  const handleDownload = () => {
    if (processedImage) {
      const link = document.createElement('a');
      link.href = processedImage;
      link.download = `passport-photo-${Date.now()}.jpg`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
  };

  const handleReset = () => {
    setSelectedFile(null);
    reset();
  };

  return (
    <div className="min-h-screen bg-background flex flex-col font-sans selection:bg-primary/20">
      {/* Header */}
      <header className="w-full border-b border-border/50 bg-background/80 backdrop-blur-md sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="bg-primary text-primary-foreground p-1.5 rounded-lg">
              <Crop className="w-5 h-5" />
            </div>
            <span className="font-display font-bold text-xl tracking-tight">AutoCrop</span>
          </div>
          <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-muted-foreground">
            <a href="#" className="hover:text-foreground transition-colors">How it works</a>
            <a href="#" className="hover:text-foreground transition-colors">Requirements</a>
            <Button variant="ghost" size="sm" className="font-semibold">Sign In</Button>
          </nav>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 w-full max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-12 md:py-20">
        <div className="text-center space-y-4 mb-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight text-foreground">
              Passport Photos, <span className="text-gradient">Perfected.</span>
            </h1>
            <p className="mt-4 text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto">
              Upload any portrait and let our AI instantly crop, resize, and format it for official documents. No manual editing required.
            </p>
          </motion.div>
        </div>

        <div className="grid lg:grid-cols-5 gap-12 items-start">
          {/* Left Column: Upload Area */}
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
            className="lg:col-span-3 space-y-8"
          >
            <div className="bg-card rounded-3xl p-1 shadow-2xl shadow-black/5 border border-border/50">
              <div className="bg-background rounded-[1.4rem] p-6 md:p-8 space-y-6">
                {!processedImage ? (
                  <>
                    <div className="flex items-center justify-between">
                      <h2 className="text-xl font-semibold">Upload Image</h2>
                      <span className="text-xs font-medium px-2.5 py-1 rounded-full bg-secondary text-secondary-foreground">Step 1 of 2</span>
                    </div>
                    
                    <Dropzone 
                      onFileSelect={setSelectedFile} 
                      selectedFile={selectedFile}
                      onClear={() => setSelectedFile(null)}
                      disabled={isProcessing}
                    />

                    {error && (
                      <Alert variant="destructive">
                        <AlertCircle className="h-4 w-4" />
                        <AlertTitle>Error</AlertTitle>
                        <AlertDescription>{error.message}</AlertDescription>
                      </Alert>
                    )}

                    <div className="flex justify-end pt-2">
                      <Button
                        onClick={handleProcess}
                        disabled={!selectedFile || isProcessing}
                        size="lg"
                        className="w-full sm:w-auto min-w-[140px] font-semibold text-base shadow-lg shadow-primary/20 transition-all hover:shadow-primary/30"
                      >
                        {isProcessing ? (
                          <>
                            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                            Processing...
                          </>
                        ) : (
                          <>
                            <Crop className="mr-2 h-4 w-4" />
                            Crop Photo
                          </>
                        )}
                      </Button>
                    </div>
                  </>
                ) : (
                  <ResultCard 
                    imageUrl={processedImage} 
                    onDownload={handleDownload}
                    onReset={handleReset}
                  />
                )}
              </div>
            </div>

            {/* Features Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 pt-8">
              <div className="flex flex-col items-center text-center space-y-2 p-4 rounded-xl bg-secondary/30 border border-border/50">
                <div className="p-2 bg-background rounded-lg shadow-sm">
                  <ShieldCheck className="w-5 h-5 text-primary" />
                </div>
                <h3 className="font-semibold text-sm">Face Detection</h3>
                <p className="text-xs text-muted-foreground">Automatically finds and centers your face</p>
              </div>
              <div className="flex flex-col items-center text-center space-y-2 p-4 rounded-xl bg-secondary/30 border border-border/50">
                <div className="p-2 bg-background rounded-lg shadow-sm">
                  <Crop className="w-5 h-5 text-primary" />
                </div>
                <h3 className="font-semibold text-sm">Smart Cropping</h3>
                <p className="text-xs text-muted-foreground">Maintains 60-65% face height ratio</p>
              </div>
              <div className="flex flex-col items-center text-center space-y-2 p-4 rounded-xl bg-secondary/30 border border-border/50">
                <div className="p-2 bg-background rounded-lg shadow-sm">
                  <Zap className="w-5 h-5 text-primary" />
                </div>
                <h3 className="font-semibold text-sm">Instant Result</h3>
                <p className="text-xs text-muted-foreground">Processed in milliseconds locally</p>
              </div>
            </div>
          </motion.div>

          {/* Right Column: Instructions */}
          <motion.div 
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.4 }}
            className="lg:col-span-2 space-y-6"
          >
            <div className="sticky top-24">
              <h3 className="font-display font-bold text-2xl mb-6">Requirements</h3>
              <ul className="space-y-6">
                {[
                  { title: "Lighting", desc: "Ensure even lighting without shadows on face or background." },
                  { title: "Expression", desc: "Neutral facial expression with both eyes open." },
                  { title: "Background", desc: "Use a plain white or off-white background." },
                  { title: "Resolution", desc: "Upload high quality image (min 600x600px)." },
                ].map((item, i) => (
                  <li key={i} className="flex gap-4">
                    <div className="flex-none flex items-center justify-center w-8 h-8 rounded-full bg-primary/10 text-primary font-bold text-sm">
                      {i + 1}
                    </div>
                    <div>
                      <h4 className="font-semibold text-foreground">{item.title}</h4>
                      <p className="text-sm text-muted-foreground mt-1 leading-relaxed">{item.desc}</p>
                    </div>
                  </li>
                ))}
              </ul>

              <div className="mt-8 p-4 bg-blue-50 dark:bg-blue-900/10 border border-blue-100 dark:border-blue-800 rounded-xl">
                <h4 className="font-semibold text-blue-800 dark:text-blue-300 text-sm mb-2">Privacy Note</h4>
                <p className="text-xs text-blue-600 dark:text-blue-400 leading-relaxed">
                  Your photos are processed securely and are not stored on our servers. They are automatically deleted after processing.
                </p>
              </div>
            </div>
          </motion.div>
        </div>
      </main>

      <StatusFooter isOnline={isApiOnline} />
    </div>
  );
}
