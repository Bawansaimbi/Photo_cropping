import { useMutation, useQuery } from "@tanstack/react-query";
import { api } from "@shared/routes";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";

// Specific hook for the photo upload since it returns a Blob, not JSON
export function usePhotoProcessor() {
  const { toast } = useToast();
  const [processedImage, setProcessedImage] = useState<string | null>(null);

  const statusQuery = useQuery({
    queryKey: [api.photo.status.path],
    queryFn: async () => {
      const res = await fetch(api.photo.status.path);
      if (!res.ok) throw new Error("API not available");
      return await res.json();
    },
    // Don't refetch too aggressively, just check once on load
    refetchOnWindowFocus: false,
  });

  const uploadMutation = useMutation({
    mutationFn: async (file: File) => {
      const formData = new FormData();
      formData.append("file", file);

      const res = await fetch(api.photo.upload.path, {
        method: "POST",
        body: formData,
        // Don't set Content-Type header manually, let browser set boundary
      });

      if (!res.ok) {
        // Try to parse error message from JSON
        let errorMessage = "Failed to process image";
        try {
          const errorData = await res.json();
          errorMessage = errorData.detail || errorData.error || errorMessage;
        } catch (e) {
          errorMessage = res.statusText;
        }
        throw new Error(errorMessage);
      }

      // Return the Blob directly
      return await res.blob();
    },
    onSuccess: (blob) => {
      // Create a local URL for the processed blob
      const url = URL.createObjectURL(blob);
      setProcessedImage(url);
      toast({
        title: "Success!",
        description: "Your photo has been cropped and processed.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Processing Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const reset = () => {
    if (processedImage) {
      URL.revokeObjectURL(processedImage);
      setProcessedImage(null);
    }
    uploadMutation.reset();
  };

  return {
    processPhoto: uploadMutation.mutate,
    isProcessing: uploadMutation.isPending,
    processedImage,
    error: uploadMutation.error,
    reset,
    apiStatus: statusQuery.data,
    isApiOnline: statusQuery.isSuccess,
  };
}
