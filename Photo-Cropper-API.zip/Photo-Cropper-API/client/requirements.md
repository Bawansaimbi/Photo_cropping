## Packages
framer-motion | For smooth layout transitions and upload animations
lucide-react | For beautiful iconography
clsx | For conditional class merging
tailwind-merge | For merging tailwind classes safely
react-dropzone | For drag and drop file upload handling

## Notes
- The API endpoint `/api/upload-photo` returns a binary Blob (image/jpeg) on success, not JSON.
- Error responses from `/api/upload-photo` are JSON `{ "detail": "..." }` or `{ "error": "..." }` with 400 status.
- We need to handle the Blob response carefully to create a downloadable URL.
- Using Google Fonts: 'Inter' for UI and 'Outfit' for headings.
