import { z } from 'zod';
import { uploadErrorSchema, statusSchema } from './schema';

export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  internal: z.object({
    message: z.string(),
  }),
};

export const api = {
  photo: {
    status: {
      method: 'GET' as const,
      path: '/api' as const,
      responses: {
        200: statusSchema,
      }
    },
    upload: {
      method: 'POST' as const,
      path: '/api/upload-photo' as const,
      responses: {
        200: z.any(), // The API returns an image file (Blob)
        400: uploadErrorSchema,
      }
    }
  }
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}