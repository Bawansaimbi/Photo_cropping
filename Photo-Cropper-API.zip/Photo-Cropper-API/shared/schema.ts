import { z } from "zod";

export const uploadErrorSchema = z.object({
  error: z.string()
});

export const statusSchema = z.object({
  message: z.string()
});