import io
from fastapi import FastAPI, UploadFile, File
from fastapi.responses import StreamingResponse, JSONResponse
import cv2
import numpy as np
from PIL import Image

app = FastAPI()

# Load the Haar Cascade classifier
face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")

@app.get("/")
def root():
    return {"message": "Passport Photo Cropping API is running"}

@app.post("/upload-photo")
async def upload_photo(file: UploadFile = File(...)):
    # 1. Input Validation
    if file.content_type not in ["image/jpeg", "image/png", "image/jpg"]:
        return JSONResponse(status_code=400, content={"error": "Only JPG, JPEG, and PNG files are allowed."})
    
    file_bytes = await file.read()
    
    # Check max file size (10MB)
    if len(file_bytes) > 10 * 1024 * 1024:
        return JSONResponse(status_code=400, content={"error": "File size exceeds 10MB limit."})
        
    try:
        # Load image with PIL
        pil_image = Image.open(io.BytesIO(file_bytes)).convert("RGB")
    except Exception:
        return JSONResponse(status_code=400, content={"error": "Invalid image file."})
        
    width, height = pil_image.size
    
    # Auto-resize if smaller than 600x600 to satisfy processing requirements
    if width < 600 or height < 600:
        scale = max(600 / width, 600 / height)
        new_width = int(width * scale)
        new_height = int(height * scale)
        pil_image = pil_image.resize((new_width, new_height), Image.Resampling.LANCZOS)
        width, height = pil_image.size
        
    # Convert PIL image to OpenCV format (BGR)
    cv_img = cv2.cvtColor(np.array(pil_image), cv2.COLOR_RGB2BGR)
    
    # Convert to grayscale for face detection
    gray = cv2.cvtColor(cv_img, cv2.COLOR_BGR2GRAY)
    
    # 2. Detect exactly one face
    faces = face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(100, 100))
    
    if len(faces) == 0:
        return JSONResponse(status_code=400, content={"error": "No face detected in the image."})
    elif len(faces) > 1:
        return JSONResponse(status_code=400, content={"error": f"Multiple faces ({len(faces)}) detected. Please upload an image with only one face."})
        
    # Extract face coordinates
    x, y, w, h_face = faces[0]
    
    # We want the face height to be 60-65% of the final image height. Let's aim for ~62.5%.
    final_box_size = int(h_face / 0.625)
    
    # Center the face
    face_center_x = x + w // 2
    face_center_y = y + h_face // 2
    
    # Calculate crop coordinates
    crop_x1 = face_center_x - final_box_size // 2
    crop_x2 = crop_x1 + final_box_size
    
    crop_y1 = face_center_y - final_box_size // 2
    crop_y2 = crop_y1 + final_box_size
    
    # Pad image if crop box goes outside boundaries
    pad_top = max(0, -crop_y1)
    pad_bottom = max(0, crop_y2 - height)
    pad_left = max(0, -crop_x1)
    pad_right = max(0, crop_x2 - width)
    
    if pad_top > 0 or pad_bottom > 0 or pad_left > 0 or pad_right > 0:
        cv_img = cv2.copyMakeBorder(cv_img, pad_top, pad_bottom, pad_left, pad_right, cv2.BORDER_CONSTANT, value=[255, 255, 255])
        crop_y1 += pad_top
        crop_y2 += pad_top
        crop_x1 += pad_left
        crop_x2 += pad_left
        
    # Perform crop
    cropped_cv = cv_img[crop_y1:crop_y2, crop_x1:crop_x2]
    
    # Resize to exactly 600x600
    resized_cv = cv2.resize(cropped_cv, (600, 600), interpolation=cv2.INTER_AREA)
    
    # Convert back to PIL for saving with DPI
    final_pil = Image.fromarray(cv2.cvtColor(resized_cv, cv2.COLOR_BGR2RGB))
    
    # Save to memory buffer
    img_byte_arr = io.BytesIO()
    final_pil.save(img_byte_arr, format='JPEG', quality=95, dpi=(300, 300))
    img_byte_arr.seek(0)
    
    return StreamingResponse(img_byte_arr, media_type="image/jpeg", headers={
        "Content-Disposition": "attachment; filename=passport_photo.jpg"
    })
