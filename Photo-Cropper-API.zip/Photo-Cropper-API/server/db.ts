// Dummy database file to satisfy instructions
export const pool = {};
export const db = {};