import type { Express } from "express";
import type { Server } from "http";
import { createProxyMiddleware } from 'http-proxy-middleware';
import { spawn } from 'child_process';

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Start python backend on port 5001
  const pythonProcess = spawn('python3', ['-m', 'uvicorn', 'main:app', '--port', '5001'], {
    stdio: 'inherit' // Pipe output to the console
  });
  
  // Cleanup python process when node exits
  process.on('exit', () => {
    pythonProcess.kill();
  });
  
  // Map /api/upload-photo -> /upload-photo
  app.all('/api/upload-photo', createProxyMiddleware({
    target: 'http://127.0.0.1:5001',
    changeOrigin: true,
    pathRewrite: { '^/api/upload-photo': '/upload-photo' }
  }));
  
  // Map /api -> /
  app.all('/api', createProxyMiddleware({
    target: 'http://127.0.0.1:5001',
    changeOrigin: true,
    pathRewrite: { '^/api': '/' }
  }));

  return httpServer;
}